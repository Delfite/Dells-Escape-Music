## Description
This mod (currently) adds 1 thing to the game. That 1 thing being the track "Forget About Freeman" from the hit game "Black Mesa" (which you should definitely buy because it's REALLY good). I also took the liberty of adding some extra *flair* in the form of sound effects to give the music that extra "OH GOD, OH SHIT, I'M NOT GONNA MAKE IT" factor.

## Video Demonstration
https://youtu.be/_kb5YALH1no

## How to Enable
In order for the mod to function properly, you will (unfortunately) need to do a few extra steps: 

1. Locate the file named "bgn.pizzatowerescapemusic.cfg" in your "..\BepInEx\config" directory.
2. Under the "Scripting" section of the config file, add "Delfite-ApparatusPulled" to the "Scripts = " string.
3. If everything was typed correctly, your config should look something like this: "Scripts = Delfite-ApparatusPulled" with commas added to seperate any other JSON files you might want to load, whether be from a mod I made or someone else.

Note: My mod ONLY adds music for when you pull the Apparatus, so if you don't hear it in-game, make sure to disable any other mods that might do something similar.